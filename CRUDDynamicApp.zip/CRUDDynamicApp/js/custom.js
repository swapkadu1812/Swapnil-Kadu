var divApplicationWrap, arrObjTbl = [],
    divApplicationWrap = getElems('id', 'applicationWrap');

document.addEventListener('DOMContentLoaded', function () {
    buildUI();
    var btnStartApp, rdoWithDiv, rdoWithTbl, rdoBtnsSection, tableSection, divSectionRow, conversionSection,
        frmDivStruct, frmTableStruct, LTblStructWrap, fstName, lstName;
    btnStartApp = getElems('id', 'btnStartApp');
    rdoWithDiv = getElems('id', 'rdoWithDiv');
    rdoWithTbl = getElems('id', 'rdoWithTbl');
    rdoBtnsSection = getElems('id', 'rdoBtnsSection');
    conversionSection = getElems('id', 'conversionSection');
    frmDivStruct = getElems('id', 'frmDivStruct');
    frmTableStruct = getElems('id', 'frmTableStruct');

    arrObjTbl = [
        {
            first_name: 'Swapnil',
            last_name: 'Kadu'
        },
        {
            first_name: 'Swapnil22',
            last_name: 'Kadu22'
        }
    ];
    createTable(arrObjTbl);

    arrObjDiv = [
        {
            first_name: 'Swapnil',
            last_name: 'Kadu'
        },
        {
            first_name: 'Swapnil22',
            last_name: 'Kadu22'
        }
    ];
    createDivTable(arrObjDiv);
});

btnStartApp.addEventListener('click', function () {
    rdoBtnsSection.setAttribute('style', 'display: ""');

    rdoWithDiv.addEventListener('click', function () {
        divSectionRow.setAttribute('style', 'display: ""');
        tableSection.setAttribute('style', 'display: none');
        conversionSection.setAttribute('style', 'display: ""');
    });

    rdoWithTbl.addEventListener('click', function () {
        tableSection.setAttribute('style', 'display: ""');
        divSectionRow.setAttribute('style', 'display: none');
        conversionSection.setAttribute('style', 'display: ""');
    });

    frmDivStruct.addEventListener('submit', function (e) {
        var count;
        count = 0;
        e.preventDefault();
        arrFormElements = frmDivStruct.elements;
        fstName = arrFormElements[0].value;
        lstName = arrFormElements[1].value;
        if ((fstName == '') && (lstName == '')) {
            alert('Fields cannot be empty! Enter fileds please.');
        } else {
            for (var i = 0; i < arrObjDiv.length; i++) {
                if ((arrObjDiv[i].first_name === fstName) && (arrObjDiv[i].last_name === lstName)) {
                    count++;
                }
            }

            if (count === 0) {
                obj = {
                    first_name: fstName,
                    last_name: lstName
                };
                arrObjDiv.push(obj);
            } else if (count > 0) {
                alert('Duplicate entries are not allowed!');
            }
            console.log(arrObjDiv);
            count = 0;
            createDivTable(arrObjDiv);
        }
    });
    frmTableStruct.addEventListener('submit', function (e) {
        var count;
        count = 0;
        e.preventDefault();
        arrFormElements = frmTableStruct.elements;
        fstName = arrFormElements[0].value;
        lstName = arrFormElements[1].value;
        if ((fstName == '') && (lstName == '')) {
            alert('Fields cannot be empty! Enter fileds please.');
        } else {
            for (var i = 0; i < arrObjTbl.length; i++) {
                if ((arrObjTbl[i].first_name === fstName) && (arrObjTbl[i].last_name === lstName)) {
                    count++;
                }
            }

            if (count === 0) {
                obj = {
                    first_name: fstName,
                    last_name: lstName
                };
                arrObjTbl.push(obj);
            } else if (count > 0) {
                alert('Duplicate entries are not allowed!');
            }
            count = 0;
            createTable(arrObjTbl);
        }
    });
});

function createTable(p_arrObjTbl) {

    var LCrTbl, thead, TR, TH, LTblStructWrap, elemAttrKeys;
    LTblStructWrap = getElems('id', 'tblStructWrap');
    LTblStructWrap.innerHTML = "";

    LCrTbl = createElements('table', {
        id: "tblStructTable",
        class: "table table-hover"
    });

    thead = createElements('thead');
    LCrTbl.appendChild(thead);

    TR = createElements('TR');
    thead.appendChild(TR);
    elemAttrKeys = Object.keys(p_arrObjTbl[0]);

    TH = createElements('TH', { scope: "col" });
    TH.innerHTML = "#";
    TR.appendChild(TH);
    for (var i = 0; i < elemAttrKeys.length; i++) {
        TH = createElements('TH', { scope: "col" });
        var hdrName = elemAttrKeys[i].replace('_', ' ');
        TH.innerHTML = hdrName;
        TR.appendChild(TH);
    }

    TH = createElements('TH', { scope: "col" });
    TH.innerHTML = "Action";
    TR.appendChild(TH);


    tbody = createElements('tbody', { id: "tblStructTBody" });
    LCrTbl.appendChild(tbody);

    for (var i = 0; i < p_arrObjTbl.length; i++) {
        TR = createElements('TR');
        TD = createElements('TD');
        TD.innerHTML = "#";
        TR.appendChild(TD);

        for (var j = 0; j < elemAttrKeys.length; j++) {
            TD = createElements('TD');
            TD.innerHTML = p_arrObjTbl[i][elemAttrKeys[j]];
            TR.appendChild(TD);
        }

        TD = createElements('TD');
        TD.innerHTML = "<button type='button' class='btn btn-sm btn-info far fa-trash' onclick='javascript:deleteRow(this)' id='btnRemoveRow'></button>";
        TR.appendChild(TD);
        tbody.appendChild(TR);
    }

    LTblStructWrap.appendChild(LCrTbl);
}

function createDivTable(p_arrObjDiv) {
    var divTable, divStructWrap, divTableCell, divTableRow, divTable, divTableHeader, divTableBody, elemAttrKeys, i, TH, hdrName;
    divStructWrap = getElems('id', 'divStructWrap');
    divStructWrap.innerHTML = '';
    divTable = createElements('div', { id: 'divStructDiv', class: 'divTable' });
    divStructWrap.appendChild(divTable);
    divTableBody = createElements('div', { class: 'divTableBody' });
    divTable.appendChild(divTableBody);
    divTableHeader = createElements('div', { class: 'divTableHeader' });
    divTableBody.appendChild(divTableHeader);

    TH = createElements('div', { class: "divTableCell" });
    TH.innerHTML = "#";
    divTableBody.appendChild(TH);

    elemAttrKeys = Object.keys(p_arrObjDiv[0]);
    for (i = 0; i < elemAttrKeys.length; i++) {
        TH = createElements('div', { class: "divTableCell" });
        hdrName = elemAttrKeys[i].replace('_', ' ');
        TH.innerHTML = hdrName;
        divTableBody.appendChild(TH);
    }

    TH = createElements('div', { class: "divTableCell" });
    TH.innerHTML = "Action";
    divTableBody.appendChild(TH);



    for (var i = 0; i < p_arrObjDiv.length; i++) {
        divTableRow = createElements('div', { class: "divTableRow", id: i });

        divTableCell = createElements('div', { class: 'divTableCell' });
        divTableCell.innerHTML = "#";
        divTableRow.appendChild(divTableCell);

        for (var j = 0; j < elemAttrKeys.length; j++) {
            divTableCell = createElements('div', { class: 'divTableCell' });
            divTableCell.innerHTML = p_arrObjDiv[i][elemAttrKeys[j]];
            divTableRow.appendChild(divTableCell);
        }
        divTableCell = createElements('div', { class: 'divTableCell' });
        divTableCell.innerHTML = "<button type='button' class='btn btn-sm btn-info far fa-trash' onclick='javascript:deleteRowDivTbl(this)' id='btnRemoveRow'></button>";

        divTableRow.appendChild(divTableCell);
        divTableBody.appendChild(divTableRow);
    }
    divStructWrap.appendChild(divTable);

}

function buildUI() {
    var rdoBtnsSection = createElements('div', {
        id: "rdoBtnsSection",
        class: "container"
    });
    rdoBtnsSection.setAttribute('style', "display: none");
    divApplicationWrap.appendChild(rdoBtnsSection);

    var rdoBtnsSectionRow = createElements('div', {
        class: "row"
    });
    rdoBtnsSection.appendChild(rdoBtnsSectionRow);

    var rdoBtnsSectionCol12 = createElements('div', {
        class: "col-md-12 text-center p-4"
    });
    rdoBtnsSectionRow.appendChild(rdoBtnsSectionCol12);

    var divRdoRadio = createElements('div', {
        class: "custom-control custom-radio custom-control-inline"
    });
    rdoBtnsSectionCol12.appendChild(divRdoRadio);

    var rdoDiv = createElements('input', {
        type: "radio",
        class: "custom-control-input",
        id: "rdoWithDiv",
        name: "strucutre"
    });
    divRdoRadio.appendChild(rdoDiv);

    var lblRdoDiv = createElements('label', {
        class: "custom-control-label",
        for: "rdoWithDiv"
    });
    lblRdoDiv.innerHTML = 'With Div';
    divRdoRadio.appendChild(lblRdoDiv);

    var tblRdoRadio = createElements('div', {
        class: "custom-control custom-radio custom-control-inline"
    });
    rdoBtnsSectionCol12.appendChild(tblRdoRadio);
    var rdoTable = createElements('input', {
        type: "radio",
        class: "custom-control-input",
        id: "rdoWithTbl",
        name: "strucutre"
    });
    tblRdoRadio.appendChild(rdoTable);

    var lblRdoTable = createElements('label', {
        class: "custom-control-label",
        for: "rdoWithTbl"
    });
    lblRdoTable.innerHTML = 'With Table';
    tblRdoRadio.appendChild(lblRdoTable);

    var divContainer = createElements('div', {
        class: "container"
    });
    divApplicationWrap.appendChild(divContainer);
    var tblSectionRow = createElements('div', {
        id: "tableSection",
        class: "row"
    });
    tblSectionRow.setAttribute('style', 'display: none');
    divContainer.appendChild(tblSectionRow);
    var tblSectionCol6 = createElements('div', {
        class: "col-md-6 text-center py-2 px-0 border border-light"
    });
    tblSectionRow.appendChild(tblSectionCol6);
    var tblSectionCol12 = createElements('div', {
        class: "col-md-12"
    });
    tblSectionCol6.appendChild(tblSectionCol12);
    var tblSectionForm = createElements('form', {
        class: "text-center p-2",
        id: "frmTableStruct"
    });
    tblSectionCol12.appendChild(tblSectionForm);
    var tblSectionFrmRow = createElements('div', {
        class: "form-row mb-4"
    });
    tblSectionForm.appendChild(tblSectionFrmRow);
    // var tblSectionFrmCol = createElements('div', {class: "col"});
    // tblSectionFrmRow.appendChild(tblSectionFrmCol);
    var tblSectionInpFNane = createElements('input', {
        type: "text",
        class: "col mr-2 form-control",
        placeholder: "First name"
    });
    tblSectionFrmRow.appendChild(tblSectionInpFNane);

    var tblSectionInpLNane = createElements('input', {
        type: "text",
        class: "col form-control",
        placeholder: "Last name"
    });
    tblSectionFrmRow.appendChild(tblSectionInpLNane);

    var tblSectionButton = createElements('button', {
        type: "submit",
        class: "btn btn-info btn-md my-0 mx-2 far fa-trash"
    });
    tblSectionFrmRow.appendChild(tblSectionButton);

    var tblStructWrap = createElements('div', {
        class: "col-md-12",
        id: "tblStructWrap"
    });
    tblSectionCol6.appendChild(tblStructWrap);

    var tblSectionCol6 = createElements('div', {
        class: "col-md-6 text-center my-2 mx-0"
    });
    tblSectionRow.appendChild(tblSectionCol6);

    var formGroup = createElements('div', {
        class: "form-group m-0"
    });
    tblSectionCol6.appendChild(formGroup);
    var tblSectionTxtArea = createElements('textarea', {
        type: "text",
        class: "form-control rounded-0",
        id: "tblStructTextarea",
        style: "height:300px"
    });
    formGroup.appendChild(tblSectionTxtArea);

    var divSectionRow = createElements('div', {
        id: "divSectionRow",
        class: "row"
    });
    divSectionRow.setAttribute('style', 'display: none');
    divContainer.appendChild(divSectionRow);
    var divSectionCol6 = createElements('div', {
        class: "col-md-6 text-center py-2 px-0 border border-light"
    });
    divSectionRow.appendChild(divSectionCol6);
    var divSectionCol12 = createElements('div', {
        class: "col-md-12"
    });
    divSectionCol6.appendChild(divSectionCol12);
    var divSectionFrm = createElements('form', {
        class: "text-center p-2",
        id: "frmDivStruct"
    });
    divSectionCol12.appendChild(divSectionFrm);
    var divSectionFrmRow = createElements('div', {
        class: "form-row mb-4"
    });
    divSectionFrm.appendChild(divSectionFrmRow);
    var divSectionInpFNane = createElements('input', {
        type: "text",
        class: "mr-2 col form-control",
        placeholder: "First Name"
    });
    divSectionFrmRow.appendChild(divSectionInpFNane);

    var divSectionInpLNane = createElements('input', {
        type: "text",
        class: "col form-control",
        placeholder: "Last Name"
    });
    divSectionFrmRow.appendChild(divSectionInpLNane);

    var divSectionButton = createElements('button', {
        type: "submit",
        class: "btn btn-info btn-md my-0 mx-2",
        placeholder: "Last name"
    });
    divSectionButton.innerHTML = "+";
    divSectionFrmRow.appendChild(divSectionButton);

    var divStructWrap = createElements('div', {
        class: "col-md-12",
        id: "divStructWrap"
    });
    divSectionCol6.appendChild(divStructWrap);

    var divSectionCol6 = createElements('div', {
        class: "col-md-6 text-center"
    });
    divSectionRow.appendChild(divSectionCol6);
    var formGroup = createElements('div', {
        class: "form-group m-0"
    });
    divSectionCol6.appendChild(formGroup);
    var tblSectionTxtArea = createElements('textarea', {
        type: "text",
        class: "form-control rounded-0",
        id: "divStructTextarea",
        style: "height:300px"
    });
    formGroup.appendChild(tblSectionTxtArea);
    var divContainer = createElements('div', {
        class: "container",
        id: "conversionSection"
    });
    divContainer.setAttribute('style', 'display: none');
    divApplicationWrap.appendChild(divContainer);
    var row = createElements('div', {
        class: "row"
    });
    divContainer.appendChild(row);

    var divSectionCol12 = createElements('div', {
        class: "col-md-12 py-4 text-center"
    });
    row.appendChild(divSectionCol12);

    var btnConvRToTbl = createElements('button', {
        type: "button",
        id: "btnConvToTbl",
        class: "btn btn-info btn-md my-0 mx-2",
        placeholder: "Last name",
        onclick: 'ConvRToTbl()'
    });
    btnConvRToTbl.innerHTML = "<";
    divSectionCol12.appendChild(btnConvRToTbl);

    var btnConvRToJSON = createElements('button', {
        type: "button",
        id: "btnConvRToJSON",
        class: "btn btn-info btn-md my-0 mx-2",
        placeholder: "Last name",
        onclick: 'ConvRToJSON()'
    });
    btnConvRToJSON.innerHTML = ">";
    divSectionCol12.appendChild(btnConvRToJSON);

}

function ConvRToJSON() {
    var tableSectionState = tableSection.style.display,
        divSectionState = divSectionRow.style.display;
    console.log(tableSectionState);
    if (tableSectionState != 'none') {
        var tblStructTextarea = getElems('id', 'tblStructTextarea');
        tblStructTextarea.value = JSON.stringify(arrObjTbl);
    }
    else if (divSectionState != 'none') {
        var divStructTextarea = getElems('id', 'divStructTextarea');
        divStructTextarea.value = JSON.stringify(arrObjDiv);
    }
}
function printError(err, explicit) {
    alert('JSON ERROR : ' + err.message);
}

function ConvRToTbl() {
    var tableSectionState = tableSection.style.display,
        divSectionState = divSectionRow.style.display;

    if (tableSectionState != 'none') {
        var tblStructTextarea = getElems('id', 'tblStructTextarea');
        try {
            var arrObjParse = JSON.parse(tblStructTextarea.value), count = 0;
            for (var i = 0; i < arrObjParse.length; i++) {
                for (var j = i; j < arrObjParse.length; j++) {
                    if (i != j) {
                        var LIsEquivalent = isEquivalent(arrObjParse[i], arrObjParse[j]);
                        if (LIsEquivalent === true) {
                            // console.log(LIsEquivalent);
                            count++;
                        }
                    }
                }
            }
            if (count === 0) {
                arrObjTbl = arrObjParse;
            }
            else {
                alert('Duplicates are not allowed!');
            }
            createTable(arrObjTbl);
        }
        catch (e) {
            if (e instanceof SyntaxError) {
                printError(e, true);
            }
            else {
                printError(e, true);
            }
        }
    }
    else if (divSectionState != 'none') {
        var divStructTextarea = getElems('id', 'divStructTextarea');
        try {
            var arrObjParse = JSON.parse(divStructTextarea.value), count = 0;

            for (var i = 0; i < arrObjParse.length; i++) {
                for (var j = i; j < arrObjParse.length; j++) {
                    if (i != j) {
                        var LIsEquivalent = isEquivalent(arrObjParse[i], arrObjParse[j]);
                        if (LIsEquivalent === true) {
                            // console.log(LIsEquivalent);
                            count++;
                        }
                    }
                }
            }
            if (count === 0) {
                arrObjDiv = arrObjParse;
            }
            else {
                alert('Duplicates are not allowed!');
            }
            createDivTable(arrObjDiv);
        } catch (e) {
            if (e instanceof SyntaxError) {
                printError(e, true);
            }
            else {
                printError(e, true);
            }
        }

    }
}

function isEquivalent(obj1, obj2) {
    // Create arrays of property names
    var aProps = Object.getOwnPropertyNames(obj1);
    var bProps = Object.getOwnPropertyNames(obj2);

    // If number of properties is different,
    // objects are not equivalent
    if (aProps.length != bProps.length) {
        return false;
    }

    for (var i = 0; i < aProps.length; i++) {
        var propName = aProps[i];

        // If values of same property are not equal,
        // objects are not equivalent
        if (obj1[propName] !== obj2[propName]) {
            return false;
        }
    }

    // If we made it this far, objects
    // are considered equivalent
    return true;
}

function createElements(p_elem, p_elemAttrs = null) {
    var elem, elemAttrKeys, elemAttrVals;
    elem = document.createElement(p_elem);
    if (p_elemAttrs != null) {
        elemAttrKeys = Object.keys(p_elemAttrs);
        elemAttrVals = Object.values(p_elemAttrs);
        for (var i = 0; i < elemAttrKeys.length; i++) {
            elem.setAttribute(elemAttrKeys[i], elemAttrVals[i]);
        }
    }
    return elem;
}

function getElems(p_attr, p_elem) {
    var LReturn;
    if (p_attr == ('id' || 'ID')) {
        LReturn = document.getElementById(p_elem);
    }
    if (p_attr == ('class' || 'CLASS')) {
        LReturn = document.getElementsByClassName(p_elem);
    }
    if (p_attr == ('tag' || 'TAG')) {
        LReturn = document.getElementsByTagName(p_elem);
    }
    if (p_attr == ('name' || 'NAME')) {
        LReturn = document.getElementsByName(p_elem);
    }

    return LReturn;
}

function deleteRow(p_this) {
    var activeRowIndex;
    activeRowIndex = p_this.parentNode.parentNode.rowIndex;
    console.log(activeRowIndex);

    // arrObjTbl[activeRowIndex][]
    arrObjTbl.splice((activeRowIndex - 1), 1);
    createTable(arrObjTbl);
}

function deleteRowDivTbl(p_this) {
    var activeRow = parseInt(p_this.parentNode.parentNode.id);
    arrObjDiv.splice(activeRow, 1);
    createDivTable(arrObjDiv);
}